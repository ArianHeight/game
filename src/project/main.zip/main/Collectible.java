package project.main;

/**
 * 
 * @author 
 * 
 * Classes that represent objects that are Collectible, i.e. Coins, extend this class. 
 *
 */

public abstract class Collectible extends GameObject {

	public Collectible(double x, double y, ID id) {
		super(x, y, id);
	}

}
