package project.main;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Rectangle;

import javax.swing.ImageIcon;

public class Player extends GameObject{
	protected double velX, velY;
	protected double vel;
	
	private Handler handler;
	private HUD hud;
	 
	public Player(int x, int y, ID id, Handler handler, HUD hud) {
		super(x, y, id);
		this.handler = handler;
		this.hud = hud;
		vel = 5;
	}
	
	public Rectangle getBounds(){
		return new Rectangle((int)winX, (int)winY, 32, 32);
	}
	
	@Override
	public void tick() {
		x += velX;
		y += velY;
		
		  
		//x = Game.clamp(x, -640, 1350);
		//y = Game.clamp(y, -640, 780);
		//x = Game.clamp(x, 0, 1350);
		//y = Game.clamp(y, 0, 780);
		
		collision();
		
	}
	
	private void collision(){
		for (int i = handler.object.size() - 1; i >= 0; i--){
			GameObject tempObject = handler.object.get(i);
			
			if (tempObject.getId() == ID.BasicEnemy || tempObject.getId() == ID.FastEnemy){
				if (getBounds().intersects(tempObject.getBounds())){
					HUD.HEALTH -= 1;
				}
			}
			if (tempObject.getId() == ID.Coin){
				if (getBounds().intersects(tempObject.getBounds())){
					hud.setCoins(hud.getCoins() + 1);
					handler.removeObject(tempObject);
				}
			}
		}
	}
	
	public void spiral(){
		for (int i = 0; i < 360; i += 10){
			handler.addObject(new FireBall(x + 16, y + 16, ID.Ball, i * 2 * Math.PI / 360, this));
		}
	}
	
	@Override
	public void render(Graphics g) {
		updateWindowCoordinates();
		if (id == ID.Player){
			g.setColor(Color.white);
		}
		else if (id == ID.Player2){
			g.setColor(Color.blue);
		}
		//int pX = (int)(this.x - Game.camera.getX()) + (Game.WIDTH / 2) - 16;
		//int pY = (int)(this.y - Game.camera.getY()) + (Game.HEIGHT / 2) - 16;
		
		// image of player
		Image img = new ImageIcon(this.getClass().getResource("/player.png")).getImage();
		// draw player
		g.drawImage(img, (int)winX, (int)winY, (int)winX + 32, (int)winY + 32, 0, 0, 32, 32, null);
	}
	
	// accessor methods
	public double getVelX(){ return velX; }
	public double getVelY(){ return velY; }
	
	// mutator methods
	public void setVelX(double velX){ this.velX = velX;	}
	public void setVelY(double velY){ this.velY = velY;	}
	public double getVel(){ return vel; }
}
