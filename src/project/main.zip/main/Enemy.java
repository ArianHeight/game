package project.main;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.Rectangle;

import javax.swing.ImageIcon;

public abstract class Enemy extends GameObject {
	protected double velX, velY;
	protected double vel;
	
	private Handler handler;
	private int health;
	private HUD hud;
	
	public Enemy(int x, int y, ID id, Handler handler, HUD hud) {
		super(x, y, id);
		
		this.handler = handler;
		this.hud = hud;
		
		velX = 2;
		velY = 2;
		vel = Math.sqrt(velX * velX + velY * velY);
		health = 100;
	}
	
	public Rectangle getBounds(){
		/*
		Camera c = Game.camera;
		return new Rectangle((int)(x - c.X), (int)(y - c.Y), 32, 32);
		*/
		return new Rectangle((int)winX, (int)winY, 32, 32);
	}
	
	private void collision(){
		for (int i = handler.object.size() - 1; i >= 0; i--){
			GameObject tempObject = handler.object.get(i);
			
			if (tempObject.getId() == ID.Ball){
				if (getBounds().intersects(tempObject.getBounds())){
					health -= (int)((Ball)tempObject).getPower();
					handler.removeObject(tempObject);
				}
			}
		}
	}

	@Override
	public void tick() {
		move();
		
		if (health <= 0){
			handler.removeObject(this);
			handler.addObject(new Coin((int)x, (int)y, ID.Coin));
			hud.setScore(hud.getScore() + 1);
		}
		collision();
	}
	
	public void move(){
		x += velX;
		y += velY;
	}

	@Override
	public void render(Graphics g) {
		Image img = new ImageIcon(this.getClass().getResource("/Zombie.png")).getImage();
		//Camera c = Game.camera;
		updateWindowCoordinates();
		//g.drawImage(img, (int)(x - c.X + Game.WIDTH / 2), (int)(y - c.Y + Game.HEIGHT / 2), (int)(x + 32 - c.X + Game.WIDTH / 2), (int)(y + 32 - c.Y + Game.HEIGHT / 2), 0, 0, 32, 32, null);
		g.drawImage(img, (int)winX, (int)winY, (int)winX + 32, (int)winY + 32, 0, 0, 32, 32, null);
	}
	
	public void setVelX(double velX){ this.velX = velX;	}
	public void setVelY(double velY){ this.velY = velY;	}
	public int getHealth(){ return health; }
}