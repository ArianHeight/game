package project.main;

public enum ID {
	Player(),
	Player2(),
	Coin(),
	//Trail(),
	BasicEnemy(),
	FastEnemy(),
	Ball();
	//SmartEnemy();
}
