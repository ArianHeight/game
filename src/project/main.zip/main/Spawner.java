package project.main;

import java.util.Random;

public class Spawner {
	private Handler handler;
	private HUD hud;
	private Random r = new Random();

	
	public Spawner(Handler handler, HUD hud){
		this.handler = handler;
		this.hud = hud;
	}
	
	public void tick(){
		int time = hud.getTime();
		if (time % 20 == 0){			
			//if (hud.getLevel() < 10){
				handler.addObject(new Zombie(r.nextInt(Game.WIDTH - 50), r.nextInt(Game.HEIGHT - 50), ID.BasicEnemy, handler, hud));
			//}
		}
		if (time % 200 == 0){
			hud.setLevel(hud.getLevel() + 1);
		}
	}
}
