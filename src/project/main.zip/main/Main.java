package project.main;

public abstract class Main {

	public static void main(String[] args) {

	}

}
