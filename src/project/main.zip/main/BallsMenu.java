package project.main;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;

import project.main.Game.STATE;


public class BallsMenu {
	
	private Game game;
	//private Random r = new Random();
	
	public BallsMenu(Game game){
		this.game = game;
	}

	public void tick(){
		
	}
	
	public void render (Graphics g){
		if (game.gameState == STATE.BallsMenu){
			Font font1 = new Font("arial", 1, 50);
			Font font2 = new Font("arial", 1, 30);
			
			g.setFont(font1);
			g.setColor(Color.white);
			g.drawString("Balls", 570, 50);
			
			g.setFont(font2);
			g.drawRect(Game.WIDTH / 2 - 100, 580, 200, 64);
			g.drawString("Back", 600, 620);
		}
	}	
}
