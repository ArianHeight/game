package project.main;

public class Zombie extends Enemy {

	public Zombie(int x, int y, ID id, Handler handler, HUD hud) {
		super(x, y, id, handler, hud);
	}
	
	public void move(){
		double xDiff = Game.player.getX() - this.x;
		double yDiff = Game.player.getY() - this.y;
		double dist = Math.sqrt((xDiff * xDiff) + (yDiff * yDiff));
		
		this.velX = vel * (xDiff / dist);
		this.velY = vel * (yDiff / dist);
		
		super.move();
	}
}
