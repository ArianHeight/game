package project.main;

import java.awt.Graphics;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Random;

import project.main.Game.STATE;

public class MouseInput extends MouseAdapter {
	
	private Game game;
	private Handler handler;
	private HUD hud;
	private Random r = new Random();
	private Player player;
	
	public MouseInput(Game game, Handler handler, Player p, HUD hud){
		this.game = game;
		this.handler = handler;
		this.player = p;
		this.hud = hud;
	}
	
	public void mousePressed(MouseEvent e){
		double mx = e.getX();
		double my = e.getY();
		
		if (game.gameState == STATE.Menu){
			// clicks play
			if (mouseOver(mx, my, Game.WIDTH / 2 - 100, 150, 200, 64)){
				game.gameState = STATE.Game;
				//for (int i = 0; i < 20; i++){
		   			handler.addObject(new Zombie(r.nextInt(Game.WIDTH), r.nextInt(Game.HEIGHT), ID.BasicEnemy, handler, hud));
				//}
				//handler.printObjects();
			}
			// clicks help
			if (mouseOver(mx, my, Game.WIDTH / 2 - 100, 250, 200, 64)){
				game.gameState = STATE.Help;
			}
			// clicks balls
			if (mouseOver(mx, my, Game.WIDTH / 2 - 100, 350, 200, 64)){
				game.gameState = STATE.BallsMenu;
			}
			// clicks balls
			if (mouseOver(mx, my, Game.WIDTH / 2 - 100, 450, 200, 64)){
				game.gameState = STATE.ZombieMenu;
			}
		}
		// clicks back
		if (game.gameState == STATE.Help){
			if (mouseOver(mx, my, Game.WIDTH / 2 - 100, 350, 200, 64)){
				game.gameState = STATE.Menu;
				return;
			}
		}
		if (game.gameState == STATE.BallsMenu){
			if (mouseOver(mx, my, Game.WIDTH / 2 - 100, 580, 200, 64)){
				game.gameState = STATE.Menu;
				return;
			}
		}
		if (game.gameState == STATE.ZombieMenu){
			if (mouseOver(mx, my, Game.WIDTH / 2 - 100, 580, 200, 64)){
				game.gameState = STATE.Menu;
				return;
			}
		}
		if (game.gameState == STATE.End){
			if (mouseOver(mx, my, Game.WIDTH / 2 - 100, 580, 200, 64)){
				game.gameState = STATE.Menu;
				game.reset();
				return;
			}
		}
		
		// in the game; adds a projectile when a position on the window is clicked
		
		if (game.gameState == STATE.Game){
			double xVal = (mx - (player.x) + Game.camera.X - Game.WIDTH / 2);
			double yVal = (my - (player.y) + Game.camera.Y - Game.HEIGHT / 2);
			
			//System.out.println(xVal + " " + yVal + " " + game.camera.X + " " + game.camera.Y);
			//System.out.println("Player X: " + player.x + " Player Y: " + player.y);
			//System.out.println("Camera X: " + game.camera.X + " Camera Y: " + game.camera.Y);
			

			//handler.addObject(new Ball(player.x + game.camera.X, player.y + game.camera.Y, ID.Ball, xVal, yVal));
			
			//handler.addObject(new Ball(game.camera.X + Game.WIDTH / 2, game.camera.Y + Game.HEIGHT / 2, ID.Ball, xVal, yVal, player));
			handler.addObject(new FireBall(player.x + 16, player.y + 16, ID.Ball, xVal, yVal, player));
			//handler.addObject(new Ball(player.x, player.y, ID.Ball, xVal, yVal));
		}
	}
	
	public void mouseReleased(MouseEvent e){
		
	}
	
	/**
	 * This method determines if a specific point on the window is bounded by a rectangle. 
	 */	
	private boolean mouseOver(double mx, double my, double x, double y, int width, int height){
		return (mx > x && mx < x + width && my > y && my < y + height);
	}
	
	public void tick(){
		
	}
	
	public void render (Graphics g){

	}	
}
