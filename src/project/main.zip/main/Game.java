package project.main;

import java.awt.Canvas;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.BufferStrategy;

import javax.swing.ImageIcon;

public class Game extends Canvas implements Runnable{

	private static final long serialVersionUID = 1550691097823471818L;
	public static final int WIDTH = 1280, HEIGHT = 720;
	public static final int tileSizeX = 64, tileSizeY = 64;
	private Thread thread;
	private boolean running = false;
	
	public static Camera camera;
	public static Player player;
	
	private Handler handler;
	private HUD hud;
	private Spawner spawner;
	
	private Menu menu;
	private BallsMenu bm;
	private ZombieMenu zm;
	private End e;
	
	private MouseInput mi;
	
	// possible states for the game to be in
	public enum STATE {
		Menu,
		BallsMenu,
		ZombieMenu,
		Help,
		Game,
		End;
	};
	
	public STATE gameState = STATE.Menu;
	
 
	public Game(){
		handler = new Handler();
		hud = new HUD();
		
		player = new Player(WIDTH/2, HEIGHT/2, ID.Player, handler, hud);
		handler.addObject(player);
		camera = new Camera(player);
		player.updateWindowCoordinates();
		menu = new Menu(this);
		bm = new BallsMenu(this);
		zm = new ZombieMenu(this);
		
		
		spawner = new Spawner(handler, hud);
		
		mi = new MouseInput(this, handler, player, hud);
		this.addMouseListener(mi);
		
		this.addKeyListener(new KeyboardInput(handler, this));
		new Window(WIDTH, HEIGHT, "Zombie Shooter", this);
  
		/*
  		for (int i = 0; i < 0; i++){
   			handler.addObject(new Coin(r.nextInt(WIDTH), r.nextInt(HEIGHT), ID.Coin));
  		}
  		*/
	}
 
	public synchronized void start(){
		thread = new Thread(this);
		thread.start();
		running = true;
	}
 
	public synchronized void stop(){
		try{
			thread.join();
			running = false;
		} catch(Exception e){
			e.printStackTrace();
		}
	}
	
	
	public void run()
    {
		
		this.requestFocus(); // need not to click on window to focus
        long lastTime = System.nanoTime();
        double amountOfTicks = 60.0;
        double ns = 1000000000 / amountOfTicks;
        double delta = 0;
        long timer = System.currentTimeMillis();
        while(running)
        {
        	long now = System.nanoTime();
        	delta += (now - lastTime) / ns;
        	lastTime = now;
        	while (delta >=1)
        	{
        		tick();
        	    delta--;
        	}
        	if(running){
        		render();
        	}
                            
            if (System.currentTimeMillis() - timer > 1000)
            {
            	timer += 1000;
            }
        }
        stop();
       
    }
 
	private void tick(){
		handler.tick();
		if (gameState == STATE.Game){
			hud.tick();
			camera.tick();
			spawner.tick();
		}
		if (HUD.HEALTH <= 0){
			HUD.HEALTH = 100;
			gameState = STATE.End;
			//handler.freezeObjects();
			//handler.clearEnemies();
			
			//hud.setLevel(1);
			//hud.setScore(0);
			e = new End(this, hud);
		}
	}
 
	private void render(){
		BufferStrategy bs = this.getBufferStrategy();
		if (bs == null){
			this.createBufferStrategy(2);
			return;
		}
  
		Graphics g = bs.getDrawGraphics();
		
		// creates the tiled background
		Image img1 = new ImageIcon(this.getClass().getResource("/blueGrass.png")).getImage();
		Image img2 = new ImageIcon(this.getClass().getResource("/stone.png")).getImage();

		for (int i = -15; i <= 3*WIDTH / tileSizeX + 1; i++){
			for (int j = -15; j <= 3*HEIGHT / tileSizeY + 1; j++){
				Image img;
				if ((i + j) % 2 == 0){
					img = img1;
				}
				else {
					img = img2;
				}
				g.drawImage(img, tileSizeX * (i-1) - (int)camera.getX(), tileSizeY * (j-1) - (int)camera.getY(), tileSizeX * i - (int)camera.getX(), tileSizeY * j - (int)camera.getY(), 0, 0, 32, 32, null);
			}
		}
		
		if (gameState == STATE.Game){
			hud.render(g);
		} 
		else if (gameState == STATE.Menu || gameState == STATE.Help){
			menu.render(g);
		}
		else if (gameState == STATE.BallsMenu){
			bm.render(g);
		}
		else if (gameState == STATE.ZombieMenu){
			zm.render(g);
		}
		else if (gameState == STATE.End){
			e.render(g);
		}
		
		handler.render(g);

		g.dispose();
		bs.show();
	}
 
    public static double clamp(double var, double min, double max){
		if (var >= max){
			return var = max;
		}
		else if (var <= min){
			return var = min;
		}
		return var;
    }
    
    public void reset(){
    	handler = new Handler();
		hud.clearAll();
		
		player = new Player(WIDTH/2, HEIGHT/2, ID.Player, handler, hud);
		handler.addObject(player);
		camera = new Camera(player);
		player.updateWindowCoordinates();
		
		spawner = new Spawner(handler, hud);
		
		mi = new MouseInput(this, handler, player, hud);
		this.addMouseListener(mi);
		this.addKeyListener(new KeyboardInput(handler, this));
    }
 
 	public static void main (String [] args){
		new Game();
    }
}
